#include "general/general.h"
#define  MAXMATRIX  100
struct var{
    int matrix[MAXMATRIX][MAXMATRIX];
    int row;
    int col;
    bool isint;
};
typedef struct var var;

#ifdef INTERP

void printvar(var*v);

//balck-box testing with assert()
bool checkint(var* v);
bool match(var*a,var*b);

//white-box testing
//initialize a var with integer x
var inttovar(int x);

//bool u_not(var* a) function(black-box testing)
//checks if var a is bigger than size 0
bool u_not(var* a);

//bool u_eightcount(var* a) function(black-box testing)
//check if var a is bigger than size 0
bool u_eightcount(var*a,var*b);


void _bop(var*a,var*b,var*c,char*op);
#endif