package edu.uob.Actions;

public abstract class BuiltInCommand extends GameAction {

}
