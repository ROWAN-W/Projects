package edu.uob;

public enum CommandTypes{
    USE,
    CREATE,
    DROP,
    ALTER,
    INSERT,
    SELECT,
    UPDATE,
    DELETE,
    JOIN
}